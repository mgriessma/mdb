"""
Mineral Formulas Database
=========================

This file contains chemical formulas for common minerals.
Format: 'Mineral Name': 'Chemical Formula'

Add new minerals by following the existing pattern.
The dictionary is case-insensitive for lookups.

Note: Some minerals have complex or variable formulas, indicated by 'Complex' or 'Variable'.
"""

# =============================================
# NATIVE ELEMENTS
# =============================================
NATIVE_ELEMENTS = {
    # Metals
    'Gold': 'Au',
    'Silber': 'Ag',
    'Kupfer': 'Cu',
    'Eisen': 'Fe',
    'Nickel': 'Ni',
    'Platin': 'Pt',
    'Palladium': 'Pd',
    'Iridium': 'Ir',
    'Osmium': 'Os',
    'Rhodium': 'Rh',
    'Ruthenium': 'Ru',
    'Aluminium': 'Al',
    'Chrom': 'Cr',
    'Mangan': 'Mn',
    'Titan': 'Ti',
    'Vanadium': 'V',
    'Cobalt': 'Co',
    'Zink': 'Zn',
    'Zinn': 'Sn',
    'Blei': 'Pb',
    'Quecksilber': 'Hg',
    'Wismut': 'Bi',
    'Antimon': 'Sb',
    'Arsen': 'As',
    'Selen': 'Se',
    'Tellur': 'Te',
    'Silizium': 'Si',

    # Non-metals
    'Schwefel': 'S₈',
    'Kohlenstoff': 'C',
    'Diamant': 'C',
    'Graphit': 'C',
}

# =============================================
# OXIDES & HYDROXIDES
# =============================================
OXIDES_HYDROXIDES = {
    'Quarz': 'SiO₂',
    'Hämatit': 'Fe₂O₃',
    'Magnetit': 'Fe₃O₄',
    'Goethit': 'FeO(OH)',
    'Limonit': 'FeO(OH)·nH₂O',
    'Corundum': 'Al₂O₃',
    'Rutil': 'TiO₂',
    'Anatas': 'TiO₂',
    'Brookit': 'TiO₂',
    'Spinell': 'MgAl₂O₄',
    'Chrysoberyll': 'BeAl₂O₄',
    'Böhmite': 'γ-AlO(OH)',
    'Diaspor': 'α-AlO(OH)',
    'Gibbsit': 'Al(OH)₃',
    'Brucit': 'Mg(OH)₂',
    'Ilmenit': 'FeTiO₃',
    'Perovskit': 'CaTiO₃',
    'Pyrolusit': 'MnO₂',
    'Kassiterit': 'SnO₂',
    'Zirkon': 'ZrSiO₄',
    'Beryll': 'Be₃Al₂(SiO₃)₆',
    'Topas': 'Al₂SiO₄(F,OH)₂',
    'Granat': 'X₃Y₂(SiO₄)₃',  # General formula
    'Staurolith': 'Fe₂Al₉O₆(SiO₄)₄(O,OH)₂',
    'Andalusit': 'Al₂SiO₅',
    'Sillimanit': 'Al₂SiO₅',
    'Kyanit': 'Al₂SiO₅',
    'Braunit': 'Mn₂O₃',
    'Chromit': 'FeCr₂O₄',
    'Columbite': '(Fe,Mn)(Nb,Ta)₂O₆',
    'Tantalite': '(Fe,Mn)(Nb,Ta)₂O₆',
    'Microlite': '(Ca,Na)₂Ta₂O₆(O,OH,F)',
    'Samarskit': '(Y,Fe,U)(Nb,Ta)O₄',
    'Fergusonit': 'Y(Nb,Ta)O₄',
    'Pyrochlore': '(Ca,Na)₂(Nb,Ta)₂O₆(O,OH,F)',
    'Baddeleyit': 'ZrO₂',
    'Psilomelan': '(Ba,H₂O)₂Mn₅O₁₀',
    'Romanechit': '(Ba,H₂O)₂Mn₅O₁₀',
    'Hollandit': 'Ba(Mn⁴⁺,Mn²⁺)₈O₁₆',
    'Cryptophan': '(Ba,H₂O)₂Mn₅O₁₀',
    'Uraninit': 'UO₂',
}

# =============================================
# SULFIDES & SULFOSALTS
# =============================================
SULFIDES = {
    'Antimonit': 'Sb₂S₃',
    'Pyrit': 'FeS₂',
    'Chalkopyrit': 'CuFeS₂',
    'Galena': 'PbS',
    'Sphalerit': 'ZnS',
    'Markasit': 'FeS₂',
    'Arsenopyrit': 'FeAsS',
    'Stibnit': 'Sb₂S₃',
    'Molybdänit': 'MoS₂',
    'Pyrrhotin': 'Fe₇S₈',
    'Bornit': 'Cu₅FeS₄',
    'Covellin': 'CuS',
    'Chalkosin': 'Cu₂S',
    'Argentit': 'Ag₂S',
    'Cinnabarit': 'HgS',
    'Realgar': 'As₄S₄',
    'Auripigment': 'As₂S₃',
    'Orpiment': 'As₂S₃',
    'Proustit': 'Ag₃AsS₃',
    'Pyrargyrit': 'Ag₃SbS₃',
    'Enargit': 'Cu₃AsS₄',
    'Tennantit': 'Cu₁₂As₄S₁₃',
    'Tetrahedrit': 'Cu₁₂Sb₄S₁₃',
    'Boulangerit': 'Pb₅Sb₄S₁₁',
    'Jamesonit': 'Pb₄FeSb₆S₁₄',
    'Bournonit': 'PbCuSbS₃',
    'Seligmannit': 'PbCuAsS₃',
    'Polybasit': '(Ag,Cu)₁₆Sb₂S₁₁',
    'Pearceit': '(Ag,Cu)₁₆As₂S₁₁',
    'Stephanit': 'Ag₅SbS₄',
    'Polyargyrit': 'Ag₁₆Sb₂S₁₁',
    'Miargyrit': 'AgSbS₂',
    'Safflorit': 'CoAs₂',
    'Löllingit': 'FeAs₂',
    'Rammelsbergit': 'NiAs₂',
    'Skutterudit': '(Co,Ni)As₃',
    'Smalit': 'CoAs₃',
    'Chloanthit': 'NiAs₂',
    'Gersdorffit': 'NiAsS',
    'Ullmannit': 'NiSbS',
    'Cobaltit': 'CoAsS',
    'Linnaeit': 'Co₃S₄',
    'Carrollit': 'CuCo₂S₄',
    'Siegenit': '(Co,Ni)₃S₄',
    'Maucherit': 'Ni₁₁As₈',
    'Nickelin': 'NiAs',
    'Breithauptit': 'NiSb',
    'Akanthit': 'Ag₂S',
    'Naumannit': 'Ag₂Se',
    'Aguilarit': 'Ag₄SeS',
    'Calaverit': 'AuTe₂',
    'Sylvanit': 'AuAgTe₄',
    'Nagyagit': 'Pb₅Au(Sb,Bi)₄S₅-₈',
    'Krennerit': 'AuTe₂',
    'Petzit': 'Ag₃AuTe₂',
    'Frohbergit': 'FeTe₂',
    'Melonit': 'NiTe₂',
    'Coloradoit': 'HgTe',
    'Eukairit': 'AgCuSe',
    'Clausthalit': 'PbSe',
    'Tiemannit': 'HgSe',
    'Berzelianit': 'Cu₂Se',
    'Umangit': 'Cu₃Se₂',
    'Guadalcazarit': 'Pb₆Cu₆Bi₅S₁₈',
}

SULFOSALTS = {
    'Bournonit': 'PbCuSbS₃',
    'Seligmannit': 'PbCuAsS₃',
    'Jamesonit': 'Pb₄FeSb₆S₁₄',
    'Boulangerit': 'Pb₅Sb₄S₁₁',
    'Meneghinit': 'Pb₁₃CuSb₇S₂₄',
    'Geocronit': 'Pb₁₄(Sb,As)₆S₂₃',
    'Plagionit': 'Pb₅Sb₈S₁₇',
    'Semseyit': 'Pb₉Sb₈S₂₁',
    'Falkmanit': 'Pb₃Sb₂S₈',
    'Baumhauerit': 'Pb₁₂As₁₆S₃₆',
}

# =============================================
# CARBONATES
# =============================================
CARBONATES = {
    'Kalzit': 'CaCO₃',
    'Aragonit': 'CaCO₃',
    'Vaterit': 'CaCO₃',
    'Dolomit': 'CaMg(CO₃)₂',
    'Ankerit': 'Ca(Fe,Mg)(CO₃)₂',
    'Siderit': 'FeCO₃',
    'Rhodochrosit': 'MnCO₃',
    'Magnesit': 'MgCO₃',
    'Smithsonit': 'ZnCO₃',
    'Malachit': 'Cu₂CO₃(OH)₂',
    'Azurit': 'Cu₃(CO₃)₂(OH)₂',
    'Apatit': 'Ca₅(PO₄)₃(OH,F,Cl)',
    'Strontianit': 'SrCO₃',
    'Witherit': 'BaCO₃',
    'Cerussit': 'PbCO₃',
    'Nahcolit': 'NaHCO₃',
    'Trona': 'Na₃H(CO₃)₂·2H₂O',
    'Thermonatrit': 'Na₂CO₃·H₂O',
    'Natrit': 'Na₂CO₃',
    'Shortit': 'Na₂Ca₂(CO₃)₃',
    'Nyerereit': 'Na₂Ca(CO₃)₂',
    'Pirssonit': 'Na₂Ca(CO₃)₂·2H₂O',
    'Gaylussit': 'Na₂Ca(CO₃)₂·5H₂O',
    'Northupit': 'Na₃Mg(CO₃)₂Cl',
    'Tychit': 'Na₆Mg₂(CO₃)₄SO₄',
    'Hydrozinkit': 'Zn₅(CO₃)₂(OH)₆',
    'Rosasit': '(Cu,Zn)₂CO₃(OH)₂',
    'Zinkrosasit': 'Zn₂CO₃(OH)₂',
    'Aurichalcit': '(Zn,Cu)₅(CO₃)₂(OH)₆',
    'Paratacamit': 'Cu₃(CO₃)₂(OH)₂',
    'Tacamit': 'Cu₃(CO₃)₂(OH)₂',
    'Clinohumit': 'Ca₉Mg(CO₃)₄(SiO₄)₄(OH)₂',
    'Chondrodit': 'Mg₅(CO₃)₄(SiO₄)₂(OH)₂',
    'Norbergit': 'Mg₃(CO₃)(SiO₄)(OH)₂',
    'Alstonit': 'BaCa(CO₃)₂',
    'Barytocalcit': 'BaCa(CO₃)₂',
    'Benstonit': '(Ba,Sr)₆Ca₆Mg(CO₃)₁₃',

}

# =============================================
# SULFATES & CHROMATES
# =============================================
SULFATES = {
    'Gips': 'CaSO₄·2H₂O',
    'Anhydrit': 'CaSO₄',
    'Baryt': 'BaSO₄',
    'Coelestin': 'SrSO₄',
    'Anglesit': 'PbSO₄',
    'Alunit': 'KAl₃(SO₄)₂(OH)₆',
    'Jarosite': 'KFe₃(SO₄)₂(OH)₆',
    'Natrojarosit': 'NaFe₃(SO₄)₂(OH)₆',
    'Hydroniumjarosit': '(H₃O)Fe₃(SO₄)₂(OH)₆',
    'Beudantit': 'PbFe₃(AsO₄,SO₄)₂(OH)₆',
    'Epsomit': 'MgSO₄·7H₂O',
    'Kieserit': 'MgSO₄·H₂O',
    'Hexahydrit': 'MgSO₄·6H₂O',
    'Pentahydrit': 'MgSO₄·5H₂O',
    'Starkeyit': 'MgSO₄·4H₂O',
    'Sanderit': 'MgSO₄·2H₂O',
    'Polyhalit': 'K₂SO₄·MgSO₄·2CaSO₄·2H₂O',
    'Glauberit': 'Na₂SO₄·CaSO₄',
    'Thenardit': 'Na₂SO₄',
    'Goslarit': 'ZnSO₄·7H₂O',
    'Bianchit': '(Zn,Fe)SO₄·6H₂O',
    'Morenosit': 'NiSO₄·7H₂O',
    'Retgersit': 'NiSO₄·6H₂O',
    'Chalcanthit': 'CuSO₄·5H₂O',
    'Pentahydrit': 'MgSO₄·5H₂O',
    'Chalcocyanit': 'CuSO₄',
    'Brochantit': 'Cu₄SO₄(OH)₆',
    'Antlerit': 'Cu₃SO₄(OH)₄',
    'Posnjakit': 'Cu₄SO₄(OH)₆·H₂O',
    'Langit': 'Cu₄SO₄(OH)₆·2H₂O',
    'Wroewolfeit': 'Cu₄SO₄(OH)₆·H₂O',
    'Serpierit': 'Ca(Cu,Zn)₄(SO₄)₂(OH)₆·3H₂O',
    'Devillit': 'CaCu₄(SO₄)₂(OH)₆·3H₂O',
    'Ktenasit': 'ZnCu₄(SO₄)₂(OH)₆·2H₂O',
    'Sciaccalugit': 'Cu₄Fe(SO₄)₂(OH)₆·2H₂O',
    'Linarit': 'PbCuSO₄(OH)₂',
    'Schultenit': 'PbH₂AsO₄',
    'Conichalcit': 'CaCuAsO₄(OH)',
    'Duftit': 'PbCuAsO₄(OH)',
    'Arseniosiderit': 'Ca₂Fe₃(AsO₄)₃(OH)₃',
    'Corkit': 'PbFe₃(PO₄,SO₄)₂(OH)₆',
    'Hinsdalit': 'PbAl₃(PO₄,SO₄)₂(OH)₆',
    'Kintoreit': 'PbFe₃(PO₄)₂(OH)₆',
    'Plumbogummit': 'PbAl₃(PO₄)₂(OH)₅·H₂O',
    'Segnitit': 'PbFe₃H₂(AsO₄)₄·8H₂O',
    'Yukonit': 'Ca₇Fe₁₀(AsO₄)₁₂·20H₂O',
}

CHROMATES = {
    'Krokoit': 'PbCrO₄',
    'Lopezit': 'K₂Cr₂O₇',
    'Tarapeacit': 'K₂CrO₄',
    'Hashemit': 'BaCrO₄',
    'Phönikochroit': 'Pb₂O(CrO₄)',
    'Vauquelinit': 'Pb₂Cu(CrO₄)PO₄(OH)',
    'Molybdochroit': 'PbCrO₄·PbMoO₄',
    'Deanesmithit': 'Hg₂⁺Hg₂²⁺CrO₄S₂',
    'Edoylerit': 'Hg₃CrO₄S₂',
}

# =============================================
# PHOSPHATES, ARSENATES, VANADATES
# =============================================
PHOSPHATES = {
    'Apatit': 'Ca₅(PO₄)₃(OH,F,Cl)',
    'Brendelit': '(Bi,Pb²⁺)₂(Fe⁴⁺,Fe²⁺)[O₂|OH|PO₄]',
    'Hydroxylapatit': 'Ca₅(PO₄)₃(OH)',
    'Fluorapatit': 'Ca₅(PO₄)₃F',
    'Chlorapatit': 'Ca₅(PO₄)₃Cl',
    'Carbonate-Fluorapatit': 'Ca₅(PO₄,CO₃)₃(F,OH)',
    'Monazit': '(Ce,La,Nd,Th)PO₄',
    'Xenotim': 'YPO₄',
    'Churchit': '(Y,Ce)PO₄·2H₂O',
    'Weinschenkit': 'YPO₄·2H₂O',
    'Chernovit': '(Y,Ce)PO₄',
    'Rhabdophan': '(Y,Ce)PO₄·H₂O',
    'Pyromorphit': 'Pb₅(PO₄)₃Cl',
    'Mimetesit': 'Pb₅(AsO₄)₃Cl',
    'Vanadinite': 'Pb₅(VO₄)₃Cl',
    'Descloizit': 'Pb(Zn,Cu)VO₄(OH)',
    'Mottramit': 'Pb(Zn,Cu)VO₄(OH)',
    'Dufrénit': 'Ca₂Fe₅(PO₄)₄(OH)₆·2H₂O',
    'Variscit': 'AlPO₄·2H₂O',
    'Metavariscit': 'AlPO₄',
    'Strengit': 'FePO₄·2H₂O',
    'Metastrengit': 'FePO₄',
    'Vivianit': 'Fe₃(PO₄)₂·8H₂O',
    'Erythrin': 'Co₃(AsO₄)₂·8H₂O',
    'Annbergit': 'Ni₃(AsO₄)₂·8H₂O',
    'Köttigit': 'Zn₃(AsO₄)₂·8H₂O',
    'Parasymplesit': 'Fe₃(AsO₄)₂·8H₂O',
    'Symplesit': 'Fe₃(AsO₄)₂·8H₂O',
    'Skorodit': 'FeAsO₄·2H₂O',
    'Mansfieldit': 'AlAsO₄·2H₂O',
    'Svarzit': 'CoAsO₄·2H₂O',
    'Roselith': '(Ca,Co,Mg)(AsO₄)·2H₂O',
    'Brandtit': 'Ca₂Mn(AsO₄)₂·2H₂O',
    'Lazulith': 'MgAl₂(PO₄)₂(OH)₂',
    'Wavellit': 'Al₃(PO₄)₂(OH)₃·5H₂O',
    'Turquoise': 'CuAl₆(PO₄)₄(OH)₈·4H₂O',
    'Chalcosiderit': 'CuFe₆(PO₄)₄(OH)₈·4H₂O',
    'Cornubit': 'Cu₅(PO₄)₂(OH)₄',
    'Libethenit': 'Cu₂PO₄(OH)',
    'Olivenit': 'Cu₂AsO₄(OH)',
    'Adamit': 'Zn₂AsO₄(OH)',
    'Paradamit': 'Zn₂AsO₄(OH)',
    'Eveit': 'Mn₂AsO₄(OH)',
    'Sarkinit': 'Mn₂AsO₄(OH)',
    'Hureaulit': 'Mn₅(PO₄)₂(VO₄)₂·10H₂O',
    'Purpurit': 'MnPO₄',
    'Heterosit': 'FePO₄',
    'Clinohumit': 'Ca₉Mg(CO₃)₄(SiO₄)₄(OH)₂',
    'Hydroxylwagnerit': 'Mg₂(PO₄)(OH)',
    'Wagnerit': 'Mg₂(PO₄)F',
    'Triploidit': '(Mn,Fe)₂(PO₄)F',
    'Triplite': '(Mn,Fe)₂(PO₄)F',
    'Zwieselit': '(Fe,Mn)₂(PO₄)F',
    'Sarcopside': '(Fe,Mn)₃(PO₄)₂',
    'Graftonit': '(Fe,Mn,Ca)₃(PO₄)₂',
    'Beraunit': 'Fe₆(PO₄)₄O(OH)₄·6H₂O',
    'Ludlamit': 'Fe₃(PO₄)₂·4H₂O',
    'Kidwellit': '(Fe,Mn)₃(PO₄)₂·4H₂O',
    'Barbosalit': 'Fe₂Fe(PO₄)₂(OH)₂',
    'Lipscombite': 'Fe₃Fe(PO₄)₂(OH)₅·2H₂O',
    'Pucherit': 'BiVO₄',
    'Neustädtelit': 'Bi₂Fe³⁺₂O₂(OH)₂(AsO₄)₂'
}

# =============================================
# SILICATES
# =============================================
SILICATES = {
    # Nesosilicates
    'Feldspat': 'KAlSi₃O₈',
    'Albit': 'NaAlSi₃O₈',
    'Anorthit': 'CaAl₂Si₂O₈',
    'Orthoklas': 'KAlSi₃O₈',
    'Mikroklin': 'KAlSi₃O₈',
    'Sanidin': 'KAlSi₃O₈',
    'Oligoklas': '(Na,Ca)(Si,Al)₄O₈',
    'Andesin': '(Na,Ca)(Si,Al)₄O₈',
    'Labradorit': '(Ca,Na)(Al,Si)₄O₈',
    'Bytownit': '(Na,Ca)(Si,Al)₄O₈',
    'Anorthoklas': '(Na,K)AlSi₃O₈',
    'Celsian': 'BaAl₂Si₂O₈',
    'Hyalophan': '(K,Ba)Al(Si,Al)₃O₈',
    'Oligoklas': '(Na,Ca)(Si,Al)₄O₈',
    'Olive': '(Mg,Fe)₂SiO₄',
    'Forsterit': 'Mg₂SiO₄',
    'Fayalit': 'Fe₂SiO₄',
    'Tephroit': 'Mn₂SiO₄',
    'Larnit': 'Ca₂SiO₄',
    'Willemit': 'Zn₂SiO₄',
    'Phenakit': 'Be₂SiO₄',
    'Zirkon': 'ZrSiO₄',
    'Thorit': 'ThSiO₄',
    'Huttonit': 'ThSiO₄',
    'Granat': 'X₃Y₂(SiO₄)₃',
    'Almandin': 'Fe₃Al₂(SiO₄)₃',
    'Pyrop': 'Mg₃Al₂(SiO₄)₃',
    'Spessartin': 'Mn₃Al₂(SiO₄)₃',
    'Grossular': 'Ca₃Al₂(SiO₄)₃',
    'Andradit': 'Ca₃Fe₂(SiO₄)₃',
    'Uvarovit': 'Ca₃Cr₂(SiO₄)₃',
    'Hydrogrossular': 'Ca₃Al₂(SiO₄)₃-2x(OH)₄x',
    'Hibschit': 'Ca₃Al₂(SiO₄)(OH)₄',
    'Katoit': 'Ca₃Al₂(SiO₄)(OH)₄',
    'Staurolith': 'Fe₂Al₉O₆(SiO₄)₄(O,OH)₂',
    'Topas': 'Al₂SiO₄(F,OH)₂',
    'Chrysoberyll': 'BeAl₂O₄',
    'Eucriptit': 'LiAlSiO₄',
    'Titanit': 'CaTiSiO₅',
    'Datolith': 'CaBSiO₄(OH)',
    'Danburit': 'CaB₂(SiO₄)₂',
    'Axinit': 'Ca₂Al₂BSi₄O₁₅(OH)',
    'Tourmalin': 'Complex',
    'Dravit': 'NaMg₃Al₆(B₃Si₆O₂₇)(OH)₄',
    'Schorl': 'NaFe₃Al₆(B₃Si₆O₂₇)(OH)₄',
    'Elbaite': 'Na(Li,Al)₃Al₆(B₃Si₆O₂₇)(OH)₄',
    'Uvite': 'CaMg₃Al₅(B₃Si₆O₂₇)(OH)₄',
    'Liddicoatit': 'Ca(Li,Al)₃Al₅(B₃Si₆O₂₇)(OH)₄',

    # Sorosilicates
    'Hemimorphit': 'Zn₄Si₂O₇(OH)₂·H₂O',
    'Lawsonit': 'CaAl₂Si₂O₇(OH)₂·H₂O',
    'Ilvait': 'CaFe₂FeSi₂O₈(OH)',
    'Allanit': 'Ca(Ce,La,Y,Ca)Al₂(Fe²⁺,Fe³⁺)(SiO₄)(Si₂O₇)O(OH)',
    'Epidot': 'Ca₂Al₂(Fe,Al)(SiO₄)(Si₂O₇)O(OH)',
    'Clinozoisit': 'Ca₂Al₃(SiO₄)(Si₂O₇)O(OH)',
    'Zoisit': 'Ca₂Al₃(SiO₄)(Si₂O₇)O(OH)',
    'Vesuvianit': 'Ca₁₀Mg₂Al₄(SiO₄)₅(Si₂O₇)₂(OH)₄',
    'Beryl': 'Be₃Al₂(SiO₃)₆',
    'Cordierit': '(Mg,Fe)₂Al₄Si₅O₁₈·nH₂O',
    'Sekaninait': 'Fe₂Al₄Si₅O₁₈·nH₂O',

    # Cyclosilicates
    'Beryll': 'Be₃Al₂(SiO₃)₆',
    'Tourmalin': 'Complex',

    # Inosilicates (Single chain)
    'Enstatit': 'MgSiO₃',
    'Ferrosilit': 'FeSiO₃',
    'Bronzit': '(Mg,Fe)SiO₃',
    'Hypersthen': '(Mg,Fe)SiO₃',
    'Diopsid': 'CaMgSi₂O₆',
    'Hedenbergit': 'CaFeSi₂O₆',
    'Augit': '(Ca,Na)(Mg,Fe,Al)(Si,Al)₂O₆',
    'Pigeonit': '(Ca,Mg,Fe)(Mg,Fe)Si₂O₆',
    'Aegirin': 'NaFeSi₂O₆',
    'Jadeit': 'NaAlSi₂O₆',
    'Spodumen': 'LiAlSi₂O₆',
    'Rhodonit': 'MnSiO₃',
    'Pyroxmangit': 'MnSiO₃',
    'Wollastonit': 'CaSiO₃',
    'Pektolith': 'NaCa₂Si₃O₈(OH)',
    'Bustamit': '(Ca,Mn)SiO₃',
    'Johannsenit': 'CaMnSiO₃',
    'Kanoit': 'MnMgSiO₃',
    'Namansilit': 'NaMnSiO₃',
    'Tremolit': 'Ca₂Mg₅Si₈O₂₂(OH)₂',
    'Aktinolith': 'Ca₂(Mg,Fe)₅Si₈O₂₂(OH)₂',
    'Hornblende': 'Ca₂(Mg,Fe,Al)₅(Si,Al)₈O₂₂(OH)₂',
    'Cummingtonit': 'Fe₂Mg₅Si₈O₂₂(OH)₂',
    'Grunerit': 'Fe₇Si₈O₂₂(OH)₂',
    'Anthophyllit': 'Mg₇Si₈O₂₂(OH)₂',
    'Gedrit': 'Mg₅Al₂Si₆O₁₈(OH)₂',
    'Holmquistit': 'Li₂Mg₃Al₂Si₈O₂₂(OH)₂',

    # Inosilicates (Double chain)
    'Stilbit': 'NaCa₄Al₈Si₂₈O₇₂·28H₂O',
    'Heulandit': '(Ca,Na)₅Al₉Si₂₇O₇₂·24H₂O',
    'Epistilbit': 'Ca₃Al₆Si₁₀O₃₂·14H₂O',
    'Brewsterit': '(Sr,Ba,Ca)Al₄Si₈O₂₄·10H₂O',
    'Mordenit': '(Ca,Na₂,K₂)Al₂Si₁₀O₂₄·7H₂O',
    'Chabasit': '(Ca,Na₂,K₂)Al₂Si₄O₁₂·6H₂O',
    'Gmelinit': '(Na,K)₄Al₄Si₈O₂₄·11H₂O',
    'Phillipsit': '(K,Na,Ca)₄Al₄Si₈O₂₄·12H₂O',
    'Harmotom': 'Ba₂Al₄Si₁₂O₃₂·12H₂O',
    'Gonnardit': '(Na,Ca)₆Al₈Si₁₀O₃₆·12H₂O',

    # Phyllosilicates (Sheet silicates)
    'Talk': 'Mg₃Si₄O₁₀(OH)₂',
    'Pyrophyllit': 'Al₂Si₄O₁₀(OH)₂',
    'Muskovit': 'KAl₂(AlSi₃O₁₀)(OH)₂',
    'Biotit': 'K(Mg,Fe)₃AlSi₃O₁₀(OH)₂',
    'Phlogopit': 'KMg₃AlSi₃O₁₀(OH)₂',
    'Fuchsit': 'K(Al,Cr)₂(Al,Cr)Si₃O₁₀(OH)₂',
    'Paragonit': 'NaAl₂(AlSi₃O₁₀)(OH)₂',
    'Lepidolith': 'K(Li,Al)₂-₃(Al,Si)₄O₁₀(OH)₂',
    'Zinnwaldit': 'K(Li,Fe,Al)₂-₃(Al,Si)₄O₁₀(OH)₂',
    'Serpentin': 'Mg₃Si₂O₅(OH)₄',
    'Chrysotil': 'Mg₃Si₂O₅(OH)₄',
    'Lizardit': 'Mg₃Si₂O₅(OH)₄',
    'Antigorit': 'Mg₃Si₂O₅(OH)₄',
    'Kaolinit': 'Al₂Si₂O₅(OH)₄',
    'Dickit': 'Al₂Si₂O₅(OH)₄',
    'Nacrit': 'Al₂Si₂O₅(OH)₄',
    'Halloyit': 'Al₂Si₂O₅(OH)₄·2H₂O',
    'Montmorillonit': '(Na,Ca)₀.₃₃(Al,Mg)₂Si₄O₁₀(OH)₂·nH₂O',
    'Beidellit': '(Na,Ca)₀.₃₃Al₂(Al,Si)₄O₁₀(OH)₂·nH₂O',
    'Nontronit': '(Na,Ca)₀.₃₃Fe₂(Al,Si)₄O₁₀(OH)₂·nH₂O',
    'Saponit': '(Ca/2,Na,K)₀.₃₃(Mg,Fe)₃(Al,Si)₄O₁₀(OH)₂·nH₂O',
    'Vermiculit': '(Mg,Fe,Al)₃(Al,Si)₄O₁₀(OH)₂·4H₂O',
    'Illit': 'K₀.₆₅Al₂(Al,Si)₄O₁₀(OH)₂',
    'Glimmer': 'KAl₂(AlSi₃O₁₀)(OH)₂',
    'Chlorit': '(Mg,Fe)₃(Si,Al)₄O₁₀(OH)₂·(Mg,Fe)₃(OH)₆',
    'Clinochlor': '(Mg,Fe)₅Al(Si,Al)₄O₁₀(OH)₈',
    'Chamosit': '(Fe,Mg)₅Al(Si,Al)₄O₁₀(OH)₈',
    'Pennin': '(Mg,Fe)₅Al(Si,Al)₄O₁₀(OH)₈',
    'Nimite': '(Ni,Mg,Fe)₅Al(Si,Al)₄O₁₀(OH)₈',
    'Cookeit': 'LiAl₄(Si,Al)₄O₁₀(OH)₈',
    'Sudoit': 'Mg₅Al(Si,Al)₄O₁₀(OH)₈',
    'Talck': 'Mg₃Si₄O₁₀(OH)₂',

    # Tektosilicates (Framework silicates)
    'Quarz': 'SiO₂',
    'Tridymit': 'SiO₂',
    'Cristobalit': 'SiO₂',
    'Coesit': 'SiO₂',
    'Stishovit': 'SiO₂',
    'Lechatelierit': 'SiO₂',
    'Chalcedon': 'SiO₂',
    'Chrysopras': 'SiO₂',
    'Achat': 'SiO₂',
    'Feldspat': 'KAlSi₃O₈',
    'Albit': 'NaAlSi₃O₈',
    'Anorthit': 'CaAl₂Si₂O₈',
    'Orthoklas': 'KAlSi₃O₈',
    'Mikroklin': 'KAlSi₃O₈',
    'Sanidin': 'KAlSi₃O₈',
    'Anorthoklas': '(Na,K)AlSi₃O₈',
    'Celsian': 'BaAl₂Si₂O₈',
    'Hyalophan': '(K,Ba)Al(Si,Al)₃O₈',
    'Nephelin': '(Na,K)AlSiO₄',
    'Leucit': 'KAlSi₂O₆',
    'Analcim': 'NaAlSi₂O₆·H₂O',
    'Pollucit': '(Cs,Na)AlSi₂O₆·H₂O',
    'Wairakit': 'CaAl₂Si₄O₁₂·2H₂O',
    'Laumontit': 'CaAl₂Si₄O₁₂·4H₂O',
    'Leonhardit': 'CaAl₂Si₄O₁₂·4H₂O',
    'Yugawaralit': 'CaAl₂Si₆O₁₆·4H₂O',
    'Scolecit': 'CaAl₂Si₃O₁₀·3H₂O',
    'Mesolit': 'Na₁₆Al₁₆Si₂₄O₈₀·16H₂O',
    'Thomsonit': '(Na,Ca)₈Al₈Si₁₆O₅₆·24H₂O',
    'Gonnardit': '(Na,Ca)₆Al₈Si₁₀O₃₆·12H₂O',
    'Natrolit': 'Na₁₆Al₁₆Si₂₄O₈₀·16H₂O',
    'Sodalith': 'Na₈Al₆Si₆O₂₄Cl₂',
    'Nosean': 'Na₈Al₆Si₆O₂₄SO₄',
    'Hauyn': '(Na,K)₈Al₆Si₆O₂₄(SO₄)₂',
    'Lazurit': 'Na₈Al₆Si₆O₂₄S₆',
    'Cancrinit': 'Na₆Ca₂Al₆Si₆O₂₄(CO₃)₂',
    'Vishnevit': 'Na₆Ca₂Al₆Si₆O₂₄(SO₄)₂',
    'Davyne': '(Na,K)₆Ca₂Al₆Si₆O₂₄Cl₂',
    'Marialit': 'Na₈Al₆Si₆O₂₄Cl₂',
    'Meionit': 'Ca₈Al₆Si₆O₂₄CO₃',
    'Scapolith': '(Na,Ca)₈Al₆Si₆O₂₄(Cl,CO₃,SO₄)₂',
    'Zeolith': 'General term',
    # Amorphe Varietaeten
    'Opal': 'SiO₂ * nH₂O',
    'Hyalit': 'SiO₂ * nH₂O',
}

# =============================================
# BORATES
# =============================================
BORATES = {
    'Borax': 'Na₂B₄O₇·10H₂O',
    'Kernit': 'Na₂B₄O₇·4H₂O',
    'Tincalconit': 'Na₂B₄O₇·5H₂O',
    'Colemanit': 'Ca₂B₆O₁₁·5H₂O',
    'Pandermit': 'Ca₄B₁₀O₁₉·7H₂O',
    'Priceit': 'Ca₄B₁₀O₁₉·7H₂O',
    'Inyoit': 'Ca₂B₆O₁₁·13H₂O',
    'Meyerhofferit': 'Ca₂B₆O₁₁·7H₂O',
    'Nobleit': 'CaB₆O₁₀·4H₂O',
    'Tunellit': 'SrB₆O₁₀·4H₂O',
    'Ginorit': 'Ca₂B₁₄O₂₃·8H₂O',
    'Veatchit': 'Sr₂B₁₁O₁₉·8H₂O',
    'Probertit': 'NaCaB₅O₉·5H₂O',
    'Ulexit': 'NaCaB₅O₉·8H₂O',
    'Fabianit': 'CaB₆O₁₀·4H₂O',
    'Howlith': 'Ca₂B₅SiO₉(OH)',
    'Szaibélyit': 'MgBO₂(OH)',
    'Ascharit': 'MgHBO₃',
    'Sassolit': 'B(OH)₃',
    'Kotoit': 'Mg₃B₂O₅',
    'Suanit': 'Mg₂B₂O₅',
    'Sinhalit': 'MgAlBO₄',
    'Warwickit': 'Mg(Ti,Al)BO₄',
    'Pinnoit': 'MgB₂O₄',
    'Lüneburgit': 'Mg₃B₂(PO₄)₂(OH)₂',
    'Seamanit': 'Mn₃B₂(PO₄)₂(OH)₂',
    'Rhodizit': '(K,Cs)Al₄Be₄B₁₁O₂₈',
    'Londaleit': 'MgB₃O₃(OH)₃·H₂O',
}

# =============================================
# TUNGSTATES & MOLYBDATES
# =============================================
TUNGSTATES_MOLYBDATES = {
    'Scheelit': 'CaWO₄',
    'Wolframit': '(Fe,Mn)WO₄',
    'Ferberit': 'FeWO₄',
    'Hübnerit': 'MnWO₄',
    'Sanmartinit': 'ZnWO₄',
    'Stolzit': 'PbWO₄',
    'Raspit': 'PbWO₄',
    'Cuproscheelit': 'CuWO₄',
    'Anthoinit': 'AlWO₄(OH)',
    'Wulfenit': 'PbMoO₄',
    'Powellit': 'CaMoO₄',
    'Ferrimolybdit': 'Fe₂(MoO₄)₃·8H₂O',
    'Lindgrenit': 'Cu₃(MoO₄)₂(OH)₂',
    'Sedovit': 'U(MoO₄)₂',
    'Umohoit': '(UO₂)MoO₄·4H₂O',
    'Coquinbite': 'Fe₂(MoO₄)₃·8H₂O',
    'Ilesit': '(Mn,Fe)(Nb,Ta)₂O₆',
}

# =============================================
# HALIDES
# =============================================
HALIDES = {
    'Halit': 'NaCl',
    'Sylvin': 'KCl',
    'Carnallit': 'KMgCl₃·6H₂O',
    'Kainit': 'KMg(SO₄)Cl·3H₂O',
    'Kieserit': 'MgSO₄·H₂O',
    'Fluorit': 'CaF₂',
    'Cryolith': 'Na₃AlF₆',
    'Chiolite': 'Na₅Al₃F₁₄',
    'Prosopit': 'CaAl₂F₈·H₂O',
    'Pachnolith': 'NaCaAlF₆·H₂O',
    'Thomsenolith': 'NaCaAlF₆·H₂O',
    'Weberit': 'Na₂MgAlF₇',
    'Gearksutit': 'CaAlF₅·H₂O',
    'Ralstonit': 'NaMgAlF₆·H₂O',
    'Atacamit': 'Cu₂Cl(OH)₃',
    'Botallackit': 'Cu₂Cl(OH)₃',
    'Clinoatacamit': 'Cu₂Cl(OH)₃',
    'Paratacamit': 'Cu₂Cl(OH)₃',
    'Boleit': 'KPb₂₆Ag₉Cu₂₄Cl₆₂(OH)₄₈',
    'Cumengit': 'Pb₁₆Cu₉Cl₄₆(OH)₄₀',
    'Diaboleit': 'Pb₂CuCl₂(OH)₄',
    'Mendipit': 'Pb₃Cl₂O₂',
    'Phosgenit': 'Pb₂CO₃Cl₂',
    'Cotunnit': 'PbCl₂',
    'Matlockit': 'PbFCl',
    'Laurionit': 'PbCl(OH)',
    'Paralaurionit': 'PbCl(OH)',
    'Fiedlerit': 'Pb₃Cl₄F(OH)₂',
    'Penfieldit': 'PbCl(OH)',
    'Calomel': 'Hg₂Cl₂',
    'Mosesit': '(Hg₂N)Cl·H₂O',
    'Terlinguait': 'Hg₂OCl',
    'Eglestonit': 'Hg₆Cl₃O',
    'Kelyanit': 'Hg₅Cl₂O₂',
    'Compreignacit': 'K₂HgCl₄',
    'Calciumchlorid': 'CaCl₂',
    'Chlorargyrit': 'AgCl',
    'Bromargyrit': 'AgBr',
    'Iodargyrit': 'AgI',
    'Miersit': '(Ag,Cu)I',
    'Marshit': 'CuI',
    'Nantokit': 'CuCl',
    'Chalkomenit': 'CuSeO₃·2H₂O',
}

# =============================================
# COMPLETE DICTIONARY
# =============================================
# Combine all dictionaries into one
COMMON_MINERALS = {}
COMMON_MINERALS.update(NATIVE_ELEMENTS)
COMMON_MINERALS.update(OXIDES_HYDROXIDES)
COMMON_MINERALS.update(SULFIDES)
COMMON_MINERALS.update(SULFOSALTS)
COMMON_MINERALS.update(CARBONATES)
COMMON_MINERALS.update(SULFATES)
COMMON_MINERALS.update(CHROMATES)
COMMON_MINERALS.update(PHOSPHATES)
COMMON_MINERALS.update(SILICATES)
COMMON_MINERALS.update(BORATES)
COMMON_MINERALS.update(TUNGSTATES_MOLYBDATES)
COMMON_MINERALS.update(HALIDES)

def get_formula(mineral_name):
    """
    Get chemical formula for a mineral name.
    Case-insensitive lookup with partial matching.
    """
    if not mineral_name or not mineral_name.strip():
        return None

    mineral_name = mineral_name.strip().title()

    # Direct match
    if mineral_name in COMMON_MINERALS:
        return COMMON_MINERALS[mineral_name]

    # Case-insensitive match
    for key, value in COMMON_MINERALS.items():
        if mineral_name.lower() == key.lower():
            return value

    # Partial matching (mineral name contains key or vice versa)
    for key, value in COMMON_MINERALS.items():
        if (mineral_name.lower() in key.lower()) or (key.lower() in mineral_name.lower()):
            return value

    # No match found
    return None